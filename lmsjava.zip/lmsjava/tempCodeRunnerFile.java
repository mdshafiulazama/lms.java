private static void saveIssuedBookData(String studentId, String bookId, String returnDate) {
        // Implement this method to save issued book data to the issued file (e.g., IssuedBooks.txt)
    }